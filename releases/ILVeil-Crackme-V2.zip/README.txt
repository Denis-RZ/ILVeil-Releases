﻿ILVeil Crackme - Native VM Runtime Variant demo

Protection profile:
- Native VM Runtime Variant
- Native Capability Gate V2
- Native target: CrackmeChallenge.LicenseValidator::NativeIntegrityGate(System.Int32,System.Int32,System.Int32,System.Int32)

This package is a demonstration artifact. It intentionally contains no PDB,
rename map, or protection log.
